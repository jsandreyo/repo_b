// Hello World header file

void getMsg2(void)
{
    printf("Hello world 2!\n");
}
