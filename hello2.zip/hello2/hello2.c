#include <stdio.h>
#include <stdlib.h>
#include "hello2.h"

int main(int argc, char *argv[]) {

    getMsg2();

    return EXIT_SUCCESS;
}
