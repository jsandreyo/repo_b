#include <stdio.h>
#include <stdlib.h>
#include "hello5.h"

int main(int argc, char *argv[]) {

    puts(getMsg5());

    return EXIT_SUCCESS;
}
