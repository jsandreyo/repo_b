// Hello World header file

const char* getMsg5()
{
    const char* m = "Hello world 5!";
    return m;
}
