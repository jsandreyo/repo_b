// Hello World header file

const char* getMsg4()
{
    const char* m = "Hello world 4!";
    return m;
}
