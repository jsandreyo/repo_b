#include <stdio.h>
#include <stdlib.h>
#include "hello6.h"

// MAIN NAME INTENTIONALLY REMOVED FOR TESTING PURPOSES
int (int argc, char *argv[]) {
        
    printf("%s", getMsg6());

    return EXIT_SUCCESS;
}
