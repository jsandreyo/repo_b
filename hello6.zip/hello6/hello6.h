// Hello World header file

char* getMsg6(void)
{
    return "Hello world 6!\n";
}