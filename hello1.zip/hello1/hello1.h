// Hello World header file

const char* getMsg1()
{
    const char* m = "Hello world 1!";
    return m;
}
