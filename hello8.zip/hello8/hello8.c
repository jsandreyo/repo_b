#include <stdio.h>
#include <stdlib.h>
#include "hello8.h"

int main(int argc, char *argv[]) {

    getMsg8();

    return EXIT_SUCCESS;
}
