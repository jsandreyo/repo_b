// Hello World header file

void getMsg8(void)
{
    printf("Hello world 8!\n");
}
