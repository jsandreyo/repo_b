#include <stdio.h>
#include <stdlib.h>
#include "hello4.h"

int main(int argc, char *argv[]) {

    puts(getMsg3_fixed());

    return EXIT_SUCCESS;
}
