// Hello World header file

const char* getMsg3_fixed()
{
    const char* m = "Hello world 3 Fixed!";
    return m;
}
