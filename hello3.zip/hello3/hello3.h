// Hello World header file

const char* getMsg3()
{
    const char* m = "Hello world 3!";
    return m;
}
