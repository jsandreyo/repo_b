#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  puts("Hello, world!");
  return EXIT_SUCCESS;
}
