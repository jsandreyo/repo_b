// Hello World header file

void getMsg7(void)
{
    printf("Hello world 7\n");
}
