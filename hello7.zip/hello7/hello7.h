// Hello World header file

char* getMsg7(void)
{
    return "Hello world 7!\n";
}