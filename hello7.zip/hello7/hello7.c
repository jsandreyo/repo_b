#include <stdio.h>
#include <stdlib.h>
#include "hello7.h"

int main(int argc, char *argv[]) {

    getMsg7();

    return EXIT_SUCCESS;
}
