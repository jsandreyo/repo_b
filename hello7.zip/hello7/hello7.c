#include <stdio.h>
#include <stdlib.h>
#include "hello7.h"

// MAIN NAME INTENTIONALLY REMOVED FOR TESTING PURPOSES
int (int argc, char *argv[]) {
        
    printf("%s", getMsg7());

    return EXIT_SUCCESS;
}
